export const metadata = {
  title: "Mini LLM Chat",
  description: "Custom LLM Chatbot",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body style={{
        margin: 0,
        fontFamily: "system-ui, sans-serif",
        background: "#0f172a",
        color: "#e5e7eb"
      }}>
        {children}
      </body>
    </html>
  );
}
