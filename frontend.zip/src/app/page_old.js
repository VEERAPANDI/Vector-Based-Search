"use client";

import { useState } from "react";

export default function Home() {
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSearch = async () => {
    if (!question.trim()) return;

    setLoading(true);
    setAnswer("");

    try {
      const res = await fetch("http://localhost:8000/search", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ question }),
      });

      const data = await res.json();
      setAnswer(data.answer);
    } catch (err) {
      setAnswer("Error fetching response");
    } finally {
      setLoading(false);
    }
  };

  return (
    <main style={styles.container}>
      <h1 style={styles.title}>PixelTech Knowledge Search</h1>

      <textarea
        placeholder="Ask a question..."
        value={question}
        onChange={(e) => setQuestion(e.target.value)}
        style={styles.textarea}
      />

      <button onClick={handleSearch} style={styles.button}>
        {loading ? "Searching..." : "Search"}
      </button>

      {answer && (
        <div style={styles.answerBox}>
          <strong>Answer:</strong>
          <p>{answer}</p>
        </div>
      )}
    </main>
  );
}

const styles = {
  container: {
    maxWidth: "700px",
    margin: "80px auto",
    padding: "20px",
    fontFamily: "sans-serif",
  },
  title: {
    marginBottom: "20px",
  },
  textarea: {
    width: "100%",
    height: "80px",
    padding: "10px",
    fontSize: "16px",
  },
  button: {
    marginTop: "12px",
    padding: "10px 20px",
    fontSize: "16px",
    cursor: "pointer",
  },
  answerBox: {
    marginTop: "20px",
    padding: "15px",
    // border: "1px solid #ddd",
    // background: "#fafafa",
  },
};
