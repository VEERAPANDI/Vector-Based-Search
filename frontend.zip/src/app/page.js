"use client";

import { useState } from "react";

export default function Home() {
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleSearch = async () => {
    if (!question.trim()) return;

    setLoading(true);
    setAnswer(null);

    try {
      const res = await fetch("http://192.168.1.60:8000/search", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ question }),
      });

      const data = await res.json();
      setAnswer(data.answer);
    } catch {
      setAnswer({ source: "error", content: "Error fetching response" });
    } finally {
      setLoading(false);
    }
  };

  const copyCode = (code) => {
    navigator.clipboard.writeText(code);
    alert("Code copied!");
  };

  return (
    <main style={styles.container}>
      <h1 style={styles.title}>PixelTech Knowledge Search</h1>

      <textarea
        placeholder="Ask a question..."
        value={question}
        onChange={(e) => setQuestion(e.target.value)}
        style={styles.textarea}
      />

      <button onClick={handleSearch} style={styles.button}>
        {loading ? "Searching..." : "Search"}
      </button>

      {answer && (
        <div style={styles.answerBox}>
          <strong>Answer:</strong>

          {/* ✅ COMPANY CONTENT */}
          {answer.source === "company" && (
            <>
              <h3>{answer.title}</h3>
              <p>{answer.content}</p>
            </>
          )}

          {/* ✅ CODE CONTENT */}
          {answer.source === "code" && (
            <div style={styles.codeBox}>
              <div style={styles.codeHeader}>
                <span>
                  {answer.language?.toUpperCase()} 
                  {/* • {answer.framework} */}
                </span>
                <button
                  style={styles.copyBtn}
                  onClick={() => copyCode(answer.content)}
                >
                  Copy
                </button>
              </div>

              <pre style={styles.pre}>
                <code>{answer.content}</code>
              </pre>
            </div>
          )}
        </div>
      )}
    </main>
  );
}


const styles = {
  container: {
    maxWidth: "750px",
    margin: "80px auto",
    padding: "20px",
    fontFamily: "sans-serif",
  },
  title: { marginBottom: "20px" },
  textarea: {
    width: "100%",
    height: "80px",
    padding: "10px",
    fontSize: "16px",
  },
  button: {
    marginTop: "12px",
    padding: "10px 20px",
    fontSize: "16px",
    cursor: "pointer",
  },
  answerBox: {
    marginTop: "20px",
    padding: "15px",
  },
  codeBox: {
    marginTop: "10px",
    border: "1px solid #ddd",
    borderRadius: "6px",
    background: "#0f172a",
  },
  codeHeader: {
    display: "flex",
    justifyContent: "space-between",
    padding: "8px 12px",
    background: "#020617",
    color: "#fff",
    fontSize: "13px",
  },
  copyBtn: {
    background: "#2563eb",
    color: "#fff",
    border: "none",
    padding: "4px 10px",
    cursor: "pointer",
    borderRadius: "4px",
  },
  pre: {
    margin: 0,
    padding: "12px",
    color: "#e5e7eb",
    overflowX: "auto",
    fontSize: "14px",
  },
};